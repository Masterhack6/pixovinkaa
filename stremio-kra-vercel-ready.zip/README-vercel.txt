# 🧩 Stremio KRA.SK Addon – Nasadenie na Vercel

Tento doplnok je pripravený na jednoduché nasadenie cez [https://vercel.com](https://vercel.com).

---

## ✅ Krok 1: Nahraj na GitHub

1. Vytvor si nový repozitár na GitHube (napr. `stremio-kra`)
2. Nahraj obsah tohto ZIPu do repozitára
   - odporúčané: odstráň `webshare.js` ak už nie je potrebný

---

## 🚀 Krok 2: Nasadenie na Vercel

1. Choď na: https://vercel.com/import/git
2. Prihlás sa a vyber repozitár (napr. `stremio-kra`)
3. Vercel automaticky zistí:
   - `api/` funkcie
   - `vercel.json` pre routing
4. Klikni **Deploy**

---

## 🌐 Po nasadení

- Manifest bude na:
  https://<vercel-app-name>.vercel.app/manifest.json

- Konfigurácia loginu:
  https://<vercel-app-name>.vercel.app/configure

Zadaj tam svoje meno a heslo do kra.sk

---

## 📌 Dôležité

- Funguje len ak doplnok používateľ najskôr nakonfiguruje cez `/configure`
- Dáta sa ukladajú do pamäte – **každý reštart Vercelu vymaže session**
- Ak chceš trvalé prihlasovanie, musíš pridať jednoduchý úložný backend (napr. Firebase, Fauna, Redis)
const axios = require('axios');

let sessionToken = null;
let credentials = {
    username: null,
    password: null
};

async function loginKra() {
    if (!credentials.username || !credentials.password) {
        console.warn('⚠️ KRA login skipped: credentials not set');
        return;
    }

    try {
        const response = await axios.post('https://api.kra.sk/api/user/login', {
            data: {
                username: credentials.username,
                password: credentials.password
            }
        });

        if (response.data && response.data.session_id) {
            sessionToken = response.data.session_id;
            console.log('✅ KRA login successful');
        } else {
            console.warn('⚠️ KRA login failed: no session_id');
        }
    } catch (err) {
        console.error('❌ KRA login error:', err.message);
    }
}

function getSessionToken() {
    return sessionToken;
}

function setCredentials({ username, password }) {
    credentials.username = username;
    credentials.password = password;
    console.log('📝 KRA credentials updated');
}

module.exports = {
    loginKra,
    getSessionToken,
    setCredentials
};
const axios = require('axios');
const { getSessionToken } = require('./kra');

const BASE_URL = 'https://stream-cinema.online/kodi/api';

async function fetchKraCatalog(type = 'movies') {
    const url = `${BASE_URL}/${type}`;
    try {
        const token = getSessionToken();
        const response = await axios.get(url, {
            headers: token ? { Authorization: `Bearer ${token}` } : {}
        });

        const items = response.data.items || response.data || [];

        return items.map((item, index) => ({
            id: `kra:${item.id || item.slug || index}`,
            type: type === 'movies' ? 'movie' : 'series',
            name: item.title || item.name || 'Neznámy názov',
            poster: item.poster || item.image || '',
            description: item.description || '',
            background: item.fanart || '',
            releaseInfo: item.year ? `${item.year}` : ''
        }));
    } catch (err) {
        console.error(`❌ Chyba pri načítaní ${type} z kra.sk:`, err.message);
        return [];
    }
}

module.exports = {
    fetchKraCatalog
};
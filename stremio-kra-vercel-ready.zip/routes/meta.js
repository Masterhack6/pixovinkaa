const express = require('express');
const router = express.Router();
const tmdb = require('../api/tmdb');
const { fetchKraCatalog } = require('../api/kraCatalog');

const kraCache = {
    movie: {},
    series: {}
};

// Kombinované metadáta z KRA a TMDB
router.get('/:type/:id.json', async (req, res) => {
    const { type, id } = req.params;
    const cleanId = id.replace('kra:', '');

    let kraItem = kraCache[type]?.[cleanId];

    if (!kraItem) {
        const list = await fetchKraCatalog(type === 'movie' ? 'movies' : 'tvshows');
        kraItem = list.find(i => i.id === `kra:${cleanId}`);
        if (kraItem) kraCache[type][cleanId] = kraItem;
    }

    let meta = kraItem || {
        id,
        type,
        name: cleanId,
        description: 'Popis nie je dostupný.'
    };

    if (kraItem?.name) {
        try {
            const tmdbMeta = await tmdb.search({ query: kraItem.name, type });
            if (tmdbMeta) {
                meta = { ...meta, ...tmdbMeta };
            }
        } catch (err) {
            console.warn('⚠️ TMDB doplnok zlyhal:', err.message);
        }
    }

    res.send({ meta });
});

module.exports = router;
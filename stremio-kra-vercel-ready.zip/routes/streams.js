const express = require('express');
const router = express.Router();
const axios = require('axios');
const { getSessionToken } = require('../api/kra');

router.get('/:type/:id.json', async (req, res) => {
    const { id } = req.params;
    const cleanId = id.replace('kra:', '');

    try {
        const token = getSessionToken();
        const response = await axios.get(`https://stream-cinema.online/kodi/upNext/${cleanId}`, {
            headers: token ? { Authorization: `Bearer ${token}` } : {}
        });

        const streamList = response.data?.strms || [];

        const streams = streamList.map(stream => ({
            title: stream.label || 'KRA stream',
            url: stream.url
        }));

        res.send({ streams });
    } catch (err) {
        console.error('❌ Chyba pri načítaní streamu z KRA:', err.message);
        res.send({ streams: [] });
    }
});

module.exports = router;
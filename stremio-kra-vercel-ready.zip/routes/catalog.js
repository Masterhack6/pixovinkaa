const express = require('express');
const router = express.Router();
const { fetchKraCatalog } = require('../api/kraCatalog');

// Katalógy z kra.sk
router.get('/:type/:id/:extra?.json', async (req, res) => {
    const { type, id } = req.params;

    if (id === 'kra-filmy' && type === 'movie') {
        const metas = await fetchKraCatalog('movies');
        res.send({ metas });
    } else if (id === 'kra-serialy' && type === 'series') {
        const metas = await fetchKraCatalog('tvshows');
        res.send({ metas });
    } else {
        res.send({ metas: [] });
    }
});

module.exports = router;
const express = require('express');
const router = express.Router();
const { setCredentials, loginKra } = require('../api/kra');

router.use(express.urlencoded({ extended: true }));

router.get('/', (req, res) => {
    res.sendFile(require('path').resolve(__dirname, '../www/configure.html'));
});

router.post('/', async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.send('❌ Meno a heslo sú povinné!');
    }

    setCredentials({ username, password });
    await loginKra();

    res.send('✅ Prihlásenie prebehlo úspešne! Môžete zatvoriť toto okno.');
});

module.exports = router;
# Stremio KRA.SK Addon

Tento doplnok umožňuje prehliadať a streamovať filmy a seriály zo servera KRA.SK (stream-cinema.online) v aplikácii Stremio.

---

## ✅ Inštalácia (na serveri)

1. Uistite sa, že máte nainštalovaný Node.js (odporúčaný v18+)
2. Nahrajte a rozbaľte tento ZIP na server
3. V koreňovom priečinku spustite:
   npm install
   node index.js

---

## 🌐 Konfigurácia prihlásenia (kra.sk)

1. Otvorte prehliadač a navštívte:
   http://<your-server-ip>:7000/configure

2. Zadajte vaše prihlasovacie údaje (meno + heslo do kra.sk)

3. Po úspešnom prihlásení bude doplnok pripravený.

---

## 🧩 Pridanie do Stremio

1. Otvorte Stremio aplikáciu
2. Choďte do: Add-ons > Community Add-ons > Install via URL
3. Zadajte:
   http://<your-server-ip>:7000/manifest.json

---

## 💡 Voliteľné: Trvalé spustenie s `pm2`

1. Nainštalujte pm2:
   npm install -g pm2

2. Spustite doplnok:
   pm2 start index.js --name stremio-kra

3. Uložte konfiguráciu:
   pm2 save
   pm2 startup

---

## 📁 Štruktúra

- `/routes/` – API endpointy pre Stremio (catalog, meta, streams, configure)
- `/api/` – logika integrácie s kra.sk a TMDB
- `/www/configure.html` – jednoduché web rozhranie na zadanie prihlasovacích údajov

---

© 2024 – Tento doplnok je neoficiálny a vyžaduje vlastný prístup ku KRA.SK